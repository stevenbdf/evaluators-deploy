# Evaluators System (Sistema de Control de Evaluadores SCE )
Is an administrative system which helps to organize all the related external evaluators' stuff for the ITR EXPO.
